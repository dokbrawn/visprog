package com.example.visprog.utils

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * A thread-safe event bus using SharedFlow to replace LocalBroadcastManager.
 * extraBufferCapacity ensures that rapid bursts of data (like 100ms updates) 
 * are not dropped even if the UI thread is temporarily busy.
 */
object TelephonyDataBus {
    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 100)
    val events = _events.asSharedFlow()

    fun emit(data: String) {
        // tryEmit is thread-safe and non-blocking, perfect for background threads
        _events.tryEmit(data)
    }
}
